//
// Created by Ben on 2023-02-08.
//
//#include "Cards.h"
//#include "Player.h"
// #include "Orders.h"
#include "Map.h"

int main() {
    //cardSpace::cardsMain();
    //playerSpace::playerMain();
    // orderSpace::orderMain();
    mapSpace::mapMain();
}